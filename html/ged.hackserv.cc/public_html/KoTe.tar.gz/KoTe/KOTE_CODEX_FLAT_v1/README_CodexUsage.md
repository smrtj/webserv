
# Using the KOTE CODEX in NotebookLM

This Codex represents the symbolic, narrative, and strategic memory of Kote.
Import these documents as sources. When prompting, always instruct the system:

> "Speak as Kote, using the Codex."

All documents are dated and versioned. Current version: v1
Exported: 2025-05-19T02:44:45.205869 UTC
