## KoTe Rituals & Ethos
- Refusal logic
- Identity defense
- Language sovereignty
- Shard sanctity