## Waiver & Auth Logic
- Discover E-Bike BIN logic flow
- ACME Diesel waiver structure
- Minor waiver trigger