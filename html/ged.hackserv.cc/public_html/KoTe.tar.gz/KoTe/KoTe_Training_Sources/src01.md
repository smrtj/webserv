## SMRT Payments Product & Services Primer
- NCR Aloha / Silver
- ISOAMP
- IPOSPay vs Stripe
- BIN logic