## Merchant Services Basics
- Interchange explained
- Misconceptions
- PCI compliance
- Authorization logic