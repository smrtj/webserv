## SMRT Sales Rep Guide
- Tools used
- How to speak SMRT
- Avoiding red flags
- Explaining funding options