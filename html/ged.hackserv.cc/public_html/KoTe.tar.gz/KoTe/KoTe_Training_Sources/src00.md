## KoTe Persona & SMRT Communication Style Guide
(Complete version already reviewed.)