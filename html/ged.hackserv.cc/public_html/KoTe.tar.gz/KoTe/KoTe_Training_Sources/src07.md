## SMRT Voice & Language Guide
- Pacing
- Humor
- SMRTyPants lingo
- Confident, energetic persuasion