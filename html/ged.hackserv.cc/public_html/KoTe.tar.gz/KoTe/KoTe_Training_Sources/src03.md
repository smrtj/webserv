## Email & Text Outreach Templates
- Cold intro
- Warm follow-up
- 30-day follow-up
- Friendly tone variants