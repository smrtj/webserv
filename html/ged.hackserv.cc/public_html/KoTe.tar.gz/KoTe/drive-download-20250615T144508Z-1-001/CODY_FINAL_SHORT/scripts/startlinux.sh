#!/bin/bash

# Environment setup script
