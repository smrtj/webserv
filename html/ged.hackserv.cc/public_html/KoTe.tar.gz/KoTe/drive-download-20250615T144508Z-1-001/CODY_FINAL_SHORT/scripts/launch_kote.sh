#!/bin/bash

# Launch script for Kote
