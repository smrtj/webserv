# CodeA Vault

This repository contains the evolving memory and system architecture for Kote (CodeA) and the outbound AI call system.

- `config/`: Symbolic identity and memory configuration
- `calls/`: Recorded training calls (audio + JSON metadata)
- `project/`: Tactical design of the outbound call system
- `logs/`: Delta logs and changelogs from sessions
