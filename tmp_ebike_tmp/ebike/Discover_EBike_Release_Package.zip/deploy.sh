#!/bin/bash
echo "[+] Installing dependencies..."
npm install express body-parser pdfkit googleapis nodemailer axios dotenv

echo "[+] Creating runtime directories..."
mkdir -p temp_waivers

echo "[+] Starting the server on port 3000..."
node server.js
