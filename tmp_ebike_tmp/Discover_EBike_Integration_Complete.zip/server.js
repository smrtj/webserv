// server.js
// Conceptual Node.js/Express server for processing e-bike waivers

const express = require('express');
const bodyParser = require('body-parser'); // Or use express.json() for newer Express versions
const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');
const { google } = require('googleapis');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.PORT || 3000; // Use environment variable for port

// Middleware
app.use(bodyParser.json()); // For parsing application/json
// Or for newer Express: app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true })); // For parsing application/x-www-form-urlencoded

// --- CONFIGURATION (Replace with your actual paths and credentials) ---
const GOOGLE_API_CREDENTIALS_PATH = path.join(__dirname, 'your-google-api-credentials.json'); // Path to your Google Service Account JSON
const GOOGLE_DRIVE_FOLDER_ID = 'YOUR_GOOGLE_DRIVE_FOLDER_ID'; // ID of the Google Drive folder to upload waivers
const MERCHANT_EMAIL = 'brandon@discoverebike.fun'; // Your business email
const GMAIL_USER = 'your-gmail-address@gmail.com'; // Gmail account used for sending emails (needs "less secure app access" or OAuth2 setup)
// For production, use OAuth2 with Nodemailer rather than direct password or less secure app access.

// --- Helper Function: Generate PDF Waiver ---
async function generateWaiverPDF(waiverData, type = 'adult') {
    return new Promise((resolve, reject) => {
        const doc = new PDFDocument({ margin: 50, size: 'A4' });
        const buffers = [];
        const fileName = `${type}_waiver_${waiverData.name ? waiverData.name.replace(/\s+/g, '_') : 'unknown'}_${Date.now()}.pdf`;
        const filePath = path.join(__dirname, 'temp_waivers', fileName); // Store temporarily or stream directly

        // Ensure temp_waivers directory exists
        if (!fs.existsSync(path.join(__dirname, 'temp_waivers'))){
            fs.mkdirSync(path.join(__dirname, 'temp_waivers'));
        }

        doc.on('data', buffers.push.bind(buffers));
        doc.on('end', () => {
            const pdfData = Buffer.concat(buffers);
            // For simplicity, we'll save it and return path. In prod, you might stream or just use buffer.
            fs.writeFile(filePath, pdfData, (err) => {
                if (err) {
                    return reject(err);
                }
                resolve({ filePath, fileName, pdfBuffer: pdfData });
            });
        });

        // --- PDF Content Generation (Customize heavily based on your HTML waiver structure) ---
        doc.fontSize(18).text(`Discover E-Bike - ${type === 'adult' ? 'Adult' : 'Minor'} Waiver`, { align: 'center' });
        doc.moveDown();

        if (type === 'adult') {
            doc.fontSize(12).text(`Renter Name: ${waiverData.name || 'N/A'}`);
            doc.text(`Email: ${waiverData.email || 'N/A'}`);
            doc.text(`Phone: ${waiverData.phone || 'N/A'}`);
            doc.moveDown();
            doc.text('Waiver Details:', { underline: true });
            doc.fontSize(8).text(JSON.stringify(waiverData.initials, null, 2)); // Example: dump initials
            // TODO: Reconstruct the full waiver text here, marking initialed sections.
            // This is a simplified representation. You'd iterate through your waiver text
            // and include it, potentially highlighting or noting the initialed parts.
            doc.moveDown();
            doc.fontSize(10).text(`Agreed to terms: ${waiverData.agreedToTerms ? 'Yes' : 'No'}`);
        } else { // Minor waiver
            doc.fontSize(12).text(`Minor Name: ${waiverData.name || 'N/A'}`);
            doc.text(`Date of Birth: ${waiverData.dob || 'N/A'}`);
            doc.text(`Parent/Guardian: ${waiverData.parentGuardianName || 'N/A'}`);
            doc.text(`Relationship: ${waiverData.parentGuardianRelationship || 'N/A'}`);
            doc.moveDown();
            doc.text('Waiver Details (Parental Initials):', { underline: true });
            doc.fontSize(8).text(JSON.stringify(waiverData.initials, null, 2));
            doc.moveDown();
            doc.fontSize(10).text(`Parent/Guardian agreed to minor terms: ${waiverData.agreedToMinorTerms ? 'Yes' : 'No'}`);
        }
        doc.moveDown(2);
        doc.fontSize(8).text(`Signed Electronically on: ${new Date().toLocaleString()}`);
        // --- End PDF Content ---

        doc.end();
    });
}

// --- Helper Function: Send Email (using Nodemailer with Gmail) ---
async function sendEmailWithAttachment(to, subject, textBody, htmlBody, attachments) {
    // For production, use OAuth2 credentials for Gmail.
    // This example might require "Less Secure App Access" to be enabled on the Gmail account, which is not recommended for production.
    let transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: GMAIL_USER, // Your Gmail email address
            pass: 'YOUR_GMAIL_APP_PASSWORD' // Your Gmail App Password (if using 2FA) or account password (less secure)
        }
    });

    let mailOptions = {
        from: `"Discover E-Bike" <${GMAIL_USER}>`,
        to: to, // list of receivers
        subject: subject,
        text: textBody,
        html: htmlBody,
        attachments: attachments // [{ filename: 'waiver.pdf', content: pdfBuffer, contentType: 'application/pdf' }]
    };

    try {
        let info = await transporter.sendMail(mailOptions);
        console.log('Email sent: %s', info.messageId);
        return info;
    } catch (error) {
        console.error('Error sending email:', error);
        throw error;
    }
}

// --- Helper Function: Upload to Google Drive ---
async function uploadToGoogleDrive(fileName, fileBuffer, mimeType = 'application/pdf') {
    const auth = new google.auth.GoogleAuth({
        keyFile: GOOGLE_API_CREDENTIALS_PATH,
        scopes: ['https://www.googleapis.com/auth/drive.file'],
    });
    const drive = google.drive({ version: 'v3', auth });

    const fileMetadata = {
        name: fileName,
        parents: [GOOGLE_DRIVE_FOLDER_ID] // Specify the folder ID
    };
    const media = {
        mimeType: mimeType,
        body: require('stream').Readable.from(fileBuffer) // Create a readable stream from buffer
    };

    try {
        const file = await drive.files.create({
            resource: fileMetadata,
            media: media,
            fields: 'id'
        });
        console.log('File Uploaded to Google Drive, File ID:', file.data.id);
        return file.data.id;
    } catch (error) {
        console.error('Error uploading to Google Drive:', error);
        throw error;
    }
}


// --- API Endpoint to process rental and waivers ---
app.post('/api/process-rental-and-waivers', async (req, res) => {
    try {
        const { adultWaiverData, minorWaiverData, paymentDetails, rentalDetails } = req.body;

        // **Step 1: Process Payment (Placeholder for iPosPays Integration)**
        // This is where you would securely send paymentDetails to iPosPays API
        // and handle their response.
        console.log('Attempting to process payment (iPosPays placeholder)...', paymentDetails);
        const paymentSuccessful = true; // <<<< REPLACE WITH ACTUAL IPOSPAYS RESPONSE
        // if (!paymentSuccessful) {
        //     return res.status(400).json({ success: false, message: 'Payment failed.' });
        // }
        console.log('Payment processed successfully (simulated).');


        // **Step 2: Generate Adult Waiver PDF**
        let adultPdfInfo;
        if (adultWaiverData) {
            adultPdfInfo = await generateWaiverPDF(adultWaiverData, 'adult');
            console.log(`Adult waiver PDF generated: ${adultPdfInfo.fileName}`);
        }

        // **Step 3: Generate Minor Waiver PDFs (if any)**
        const minorPdfInfos = [];
        if (minorWaiverData && minorWaiverData.length > 0) {
            for (const minorData of minorWaiverData) {
                const minorPdf = await generateWaiverPDF(
                    { ...minorData, parentGuardianName: adultWaiverData.name, parentGuardianRelationship: adultWaiverData.parentGuardianRelationship, agreedToMinorTerms: adultWaiverData.agreedToMinorTerms },
                     'minor'
                );
                minorPdfInfos.push(minorPdf);
                console.log(`Minor waiver PDF generated: ${minorPdf.fileName}`);
            }
        }

        // **Step 4: Prepare Attachments for Emails**
        const renterAttachments = [];
        const merchantAttachments = [];

        if (adultPdfInfo) {
            renterAttachments.push({ filename: adultPdfInfo.fileName, content: adultPdfInfo.pdfBuffer, contentType: 'application/pdf' });
            merchantAttachments.push({ filename: adultPdfInfo.fileName, content: adultPdfInfo.pdfBuffer, contentType: 'application/pdf' });
        }
        minorPdfInfos.forEach(pdf => {
            renterAttachments.push({ filename: pdf.fileName, content: pdf.pdfBuffer, contentType: 'application/pdf' });
            merchantAttachments.push({ filename: pdf.fileName, content: pdf.pdfBuffer, contentType: 'application/pdf' });
        });


        // **Step 5: Email Renter**
        if (adultWaiverData && adultWaiverData.email) {
            const renterSubject = 'Your Discover E-Bike Rental Confirmation & Waiver';
            const renterHtmlBody = `
                <h1>Thank you for your rental, ${adultWaiverData.name}!</h1>
                <p>Your e-bike rental with Discover E-Bike is confirmed.</p>
                <p>Please find attached your signed waiver(s).</p>
                <p>We look forward to seeing you at 109 N Oak St, Port Angeles, WA 98362!</p>
                <p>Questions? Call us at 360.460.1218.</p>
            `;
            await sendEmailWithAttachment(adultWaiverData.email, renterSubject, renterHtmlBody, renterHtmlBody, renterAttachments);
        }

        // **Step 6: Email Merchant / Upload to Google Drive**
        const merchantSubject = `New E-Bike Rental & Waiver: ${adultWaiverData ? adultWaiverData.name : 'N/A'}`;
        let merchantHtmlBody = `
            <h1>New E-Bike Rental</h1>
            <p><strong>Renter:</strong> ${adultWaiverData ? adultWaiverData.name : 'N/A'}</p>
            <p><strong>Email:</strong> ${adultWaiverData ? adultWaiverData.email : 'N/A'}</p>
            <p><strong>Phone:</strong> ${adultWaiverData ? adultWaiverData.phone : 'N/A'}</p>
            <p><strong>Number of Minors:</strong> ${minorWaiverData ? minorWaiverData.length : 0}</p>
            <p>Rental Details (example): ${JSON.stringify(rentalDetails || {}, null, 2)}</p>
            <p>Signed waiver(s) are attached.</p>
        `;

        // Option A: Email to Merchant
        await sendEmailWithAttachment(MERCHANT_EMAIL, merchantSubject, merchantHtmlBody, merchantHtmlBody, merchantAttachments);

        // Option B: Upload to Google Drive (can do this in addition to or instead of email)
        if (adultPdfInfo) {
            await uploadToGoogleDrive(adultPdfInfo.fileName, adultPdfInfo.pdfBuffer);
        }
        for (const pdf of minorPdfInfos) {
            await uploadToGoogleDrive(pdf.fileName, pdf.pdfBuffer);
        }
        merchantHtmlBody += `<p>Waivers also uploaded to Google Drive.</p>`; // Update email if also uploaded


        // **Step 7: Clean up temporary PDF files (if saved locally)**
        if (adultPdfInfo && fs.existsSync(adultPdfInfo.filePath)) fs.unlinkSync(adultPdfInfo.filePath);
        minorPdfInfos.forEach(pdf => {
            if (fs.existsSync(pdf.filePath)) fs.unlinkSync(pdf.filePath);
        });

        res.status(200).json({ success: true, message: 'Rental processed, waivers generated and handled.' });

    } catch (error) {
        console.error('Error processing rental:', error);
        res.status(500).json({ success: false, message: 'An error occurred on the server.', error: error.message });
    }
});


// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    // Create temp_waivers directory if it doesn't exist
    if (!fs.existsSync(path.join(__dirname, 'temp_waivers'))){
        fs.mkdirSync(path.join(__dirname, 'temp_waivers'));
        console.log("Created temp_waivers directory for temporary PDF storage.");
    }
});
