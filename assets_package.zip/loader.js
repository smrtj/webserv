const hostname = window.location.hostname.toLowerCase();

let prefix = 'smrt';

if (hostname.includes('hackserv.cc') || hostname.includes('hackserv.org')) {
  prefix = 'hack';
} else if (hostname.includes('teamkjo.com') || hostname.includes('kjo.ai')) {
  prefix = 'kjo';
} else if (hostname.includes('smrtpayments.com')) {
  prefix = 'smrt';
}

const positions = [
  { base: 'top-left', style: 'position:fixed; top:12px; left:12px; z-index:9999;' },
  { base: 'top-right', style: 'position:fixed; top:12px; right:12px; z-index:9999;' },
  { base: 'bottom-left', style: 'position:fixed; bottom:12px; left:12px; z-index:9999;' },
  { base: 'bottom-center', style: 'position:fixed; bottom:12px; left:50%; transform:translateX(-50%); z-index:9999;' },
  { base: 'bottom-right', style: '' },
  { base: 'elevenlabs-widget', style: '' },
];

positions.forEach(pos => {
  const url = `/assets/${prefix}-${pos.base}.html`;
  fetch(url)
    .then(response => response.text())
    .then(html => {
      const container = document.createElement('div');
      if (pos.style) container.style = pos.style;
      container.innerHTML = html;
      document.body.appendChild(container);
    })
    .catch(err => console.error(`Failed to load ${url}:`, err));
});
